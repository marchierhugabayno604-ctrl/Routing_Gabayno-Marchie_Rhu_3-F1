import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);
router.get("/id", (req, res)=> {
    res.send("What is your Id number?");
});

router.get("/userName/:id", (req, res) =>{
    const userName = req.params.id;
    console.log(userName);
});
router.get("/getSend/:id", (req, res) => {
    const name = req.params.id;
    res.send(`Name: ${name}`)
});

router.get("/addUser", (req, res) => {
 const user = ["lili, Marchie, Earl"];
 res.json(user);
 });

export default router;