  
import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);
router.get("/Name", (req, res)=> {
    res.send("Name: Marchie Rhu C. Gabayno");

});
export default router;
