import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);
router.get("/status", (req, res) => {
 res.json({
 name: "lili",
 age: "20",
 address:"bongabong"
 });
});
export default router;
