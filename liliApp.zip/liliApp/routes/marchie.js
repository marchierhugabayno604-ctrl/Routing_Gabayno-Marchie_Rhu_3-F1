import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);
router.get("/home", (req, res)=> {
    res.send("Welcome to the Home Page!");

});
export default router;