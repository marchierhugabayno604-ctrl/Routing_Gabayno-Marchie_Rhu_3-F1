import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);
router.get("/back", (req, res)=> {
    res.send("Welcome Back!");

});
export default router;