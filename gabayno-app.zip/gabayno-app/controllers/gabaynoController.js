export const getHome = (req, res) => {
  res.render("home", { title: "Home Page" });
};

export const getAbout = (req, res) => {
  res.send("Welcome to the About Page");
};

export const getServices = (req, res) => {
  res.json({
    status: "success",
    services: ["Web Development", "UI/UX Design", "API Development"]
  });
};

export const getUserProfile = (req, res) => {
  const userId = req.params.id;
  res.send(`Displaying profile for User ID: ${userId}`);
};

export const handleContact = (req, res) => {
  const { name, email, message } = req.body;
  res.json({
    status: "success",
    message: `Thank you ${name}, your message has been received!`
  });
};