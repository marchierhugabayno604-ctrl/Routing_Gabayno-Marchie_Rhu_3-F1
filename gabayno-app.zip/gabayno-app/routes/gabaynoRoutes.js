import express from "express";
import { 
  getHome, 
  getAbout, 
  getServices, 
  getUserProfile, 
  handleContact 
} from "../controllers/gabaynoController.js";

const router = express.Router();

router.get("/", getHome);
router.get("/about", getAbout);
router.get("/services", getServices);
router.get("/profile/:id", getUserProfile);
router.post("/contact", handleContact);

export default router;